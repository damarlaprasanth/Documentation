create table Bharath.Country(
Id int identity,
CountryId int Primary Key,
CountryName varchar(50)
)


insert into Bharath.Country values(2,'USA')
create table Bharath.City
(
Id int Identity,
CityId int primary key,
CityName varchar(50),
Stid int constraint stid_fk1 foreign key(Stid) references Bharath.State(Stid)
)
insert into Bharath.City values(4,'Uppal',1)

create table Bharath.State(
id int identity,Stid int primary key,
StName varchar(50),
CountryId int constraint CountryId_fk1 foreign key(CountryId) references Bharath.Country(CountryId)
)
select * from Bharath.State
insert into Bharath.State values(4,'TamilNadu',1)




create table Bharath.SourceAddress(
SrId int primary key,
SrName varchar(20)
)
drop table Bharath.SourceAddress
select * from Bharath.SourceAddress
--select * from Bharath.DestinationAddress
insert into Bharath.SourceAddress values(1,'Mind Space')
insert into Bharath.SourceAddress values(2,'KukatPally')
insert into Bharath.SourceAddress values(3,'LB Nagar')
insert into Bharath.SourceAddress values(4,'Uppal')


create table Bharath.DestinationAddress(
DaId int primary key ,
DaName varchar(20),
SrId int constraint SrId_fk1 foreign key(SrId) references Bharath.SourceAddress(SrId)
)

drop table Bharath.DestinationAddress
select * from Bharath.DestinationAddress
insert into Bharath.DestinationAddress values(1,'Mind Space',1)
insert into Bharath.DestinationAddress values(2,'KukatPally',1)
insert into Bharath.DestinationAddress values(3,'LB Nagar',1)
insert into Bharath.DestinationAddress values(4,'Uppal',1)

create table Bharath.Fare(
Fid int primary key,
FPrice varchar(20) ,
DaId int constraint DaId_fk1 foreign key(DaId) references Bharath.DestinationAddress(DaID)
)
insert into Bharath.Fare values(1,50,1)
insert into Bharath.Fare values(2,100,1)
insert into Bharath.Fare values(3,60,1)
insert into Bharath.Fare values(4,80,1)

drop table Bharath.Fare